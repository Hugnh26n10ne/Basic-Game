Animations are 8 Frames

Frame size: 176x128
Square size: 16x16

Every square can be mixed and match, be creative!


License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

Can be used for personal and commercial projects.
Credit (link to https://opengameart.org/content/grasswater-16x16-tiles) appreciated but no required.
